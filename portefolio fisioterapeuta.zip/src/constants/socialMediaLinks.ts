import Instagram from "@/components/Icons/Instagram";

export const socialMediaLinks = [
  {
    id: 1,
    label: "Visite meu perfil no Instagram",
    icon: Instagram,
    url: "https://www.instagram.com/teciliasantos.fisio/",
  },
];
