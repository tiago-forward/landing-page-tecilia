export const navigationLinks = [
  {
    id: 1,
    label: "Sobre Mim",
    url: "#sobre",
  },
  {
    id: 2,
    label: "Serviços",
    url: "#serviços",
  },
  {
    id: 3,
    label: "Depoimentos",
    url: "#depoimentos",
  },
  {
    id: 4,
    label: "Contato",
    url: "#contato",
  },
];
