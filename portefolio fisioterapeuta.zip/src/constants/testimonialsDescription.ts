export const TestimonialsDescription = [
  {
    nome: "Luísa Barwinski",
    cargo: "Growth Product Manager",
    texto: "Poucas vezes eu vi uma profissional tão boa",
  },
  {
    nome: "Marcos Ribeiro",
    cargo: "Professor de Educação Física",
    texto: "Passei anos com dores no ombro...",
  },
  {
    nome: "Renata Lopes",
    cargo: "Advogada",
    texto: "O atendimento foi extremamente humanizado...",
  },
  {
    nome: "Renata Lopes",
    cargo: "Advogada",
    texto: "O atendimento foi extremamente humanizado...",
  },
];
